"""Verify atomized statements and serialize a four-named-graph nanopublication per claim."""
import argparse
import json
from collections import defaultdict
from pathlib import Path
from urllib.parse import quote as uri_escape
from evidence import Evidence, digest, load, save

RELATIONS = {"measures","uses","has_value","compares_with","exceeds","supports","associated_with","part_of","depends_on","observes","other"}
MODES = {"direct","inferred","reported_by_others","hypothesis"}
POLARITIES = {"positive","negative","inconclusive"}
BASE = "urn:research-np:"


def literal(value):
    return json.dumps(str(value),ensure_ascii=False)


def iri(token):
    return "<"+BASE+uri_escape(str(token),safe="")+">"


def graph_text(claims, meta):
    out = ["@prefix np: <http://www.nanopub.org/nschema#> .",
           "@prefix prov: <http://www.w3.org/ns/prov#> .",
           "@prefix ex: <urn:research-np:vocab:> .",""]
    for c in claims:
        n = c["id"]
        head, assertion, provenance, pub = [iri(n+s) for s in ("-head","-assertion","-provenance","-pubinfo")]
        ref = iri(n)
        out.append(f"{head} {{ {ref} a np:Nanopublication ; np:hasAssertion {assertion} ; np:hasProvenance {provenance} ; np:hasPublicationInfo {pub} . }}")
        # Reify propositions so a hypothesis or negated comparison is never exported as a positive fact.
        properties = ["a ex:Claim"] + [f"ex:{k} {literal(c[k])}" for k in
                     ("subject","predicate","object","polarity","mode","conditions","statement","confidence_basis")]
        if c.get("relation_label"):
            properties.append("ex:relationLabel " + literal(c["relation_label"]))
        out.append(assertion+" { "+iri(n+"-proposition")+" "+" ; ".join(properties)+" . }")
        rows=[]
        for idx,e in enumerate(c["evidence"],1):
            ev = iri(f"{n}-e{idx}")
            doc = iri("document-"+e["source"])
            rows += [f"{assertion} prov:wasDerivedFrom {ev} .",
                     f"{ev} prov:wasDerivedFrom {doc} ; ex:locator {literal(e['locator'])} ; ex:start {e['start']} ; ex:end {e['end']} ; ex:quotation {literal(e['quote'])} ; ex:blockHash {literal(e['block_sha256'])} ."]
            for key in ("title","authors","year","doi","version","filename","file_sha256"):
                val = meta[e["source"]].get(key)
                for v in val if isinstance(val,list) else [val]:
                    if v is not None:
                        rows.append(f"{doc} ex:{key} {literal(v)} .")
        out.append(provenance+" { "+" ".join(dict.fromkeys(rows))+" }")
        out.append(f"{pub} {{ {ref} ex:serializationVersion {literal('1')} ; ex:contentId {literal(n)} . }}\n")
    return "\n".join(out)


def process(corpus, draft):
    evidence = Evidence(corpus)
    by_id, review, groups = {}, [], defaultdict(list)
    for index, candidate in enumerate(draft["claims"],1):
        try:
            c = {k:candidate[k].strip() for k in ("subject","predicate","object","conditions","polarity","mode","statement","confidence_basis")}
            if not all(c[k] for k in c if k != "conditions"):
                raise ValueError("empty required field")
            if c["predicate"] not in RELATIONS or c["polarity"] not in POLARITIES or c["mode"] not in MODES:
                raise ValueError("unknown predicate, polarity or evidence mode")
            if c["predicate"] == "other":
                c["relation_label"] = candidate["relation_label"].strip()
                if not c["relation_label"]:
                    raise ValueError("other requires a specific relation_label")
            c["evidence"] = evidence.bind(candidate["evidence"])
            docs = sorted({e["source"] for e in c["evidence"]})
            identity = [docs]+[c.get(k,"") for k in ("subject","predicate","relation_label","object","conditions","polarity","mode")]
            ident = "np-"+digest(json.dumps(identity,ensure_ascii=False))[:24]
            if ident in by_id:
                prior = by_id[ident]["evidence"]
                prior.extend(e for e in c["evidence"] if e not in prior)
                continue
            c["id"] = ident
            by_id[ident] = c
            groups[(tuple(docs),c["subject"],c["predicate"],c.get("relation_label",""),c["conditions"])].append(c)
        except (ValueError, KeyError, TypeError, AttributeError) as exc:
            review.append({"candidate":index,"reason":str(exc)})
    disagreements = []
    for group in groups.values():
        if len(group)>1 and (len({c["polarity"] for c in group})>1 or
                              group[0]["predicate"]=="has_value" and len({c["object"] for c in group})>1):
            disagreements.append({"ids":[c["id"] for c in group],"reason":"potential disagreement; recheck referent, uncertainty and conditions"})
    return {"claims":list(by_id.values()),"review":review,"possible_conflicts":disagreements,
            "status":"partial" if review or disagreements or not by_id else "validated_evidence"},evidence.meta


def main():
    p=argparse.ArgumentParser()
    p.add_argument("corpus",type=Path)
    p.add_argument("draft",type=Path)
    p.add_argument("out",type=Path)
    a=p.parse_args()
    result, meta = process(load(a.corpus),load(a.draft))
    save(a.out/"assertions.json",{**result,"sources":meta})
    (a.out/"nanopublications.trig").write_text(graph_text(result["claims"],meta),encoding="utf-8")


if __name__=="__main__":
    main()

