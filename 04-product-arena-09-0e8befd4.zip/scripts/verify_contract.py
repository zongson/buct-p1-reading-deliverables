"""Check the actual case_id and unambiguously declared parts of an output contract."""
import argparse
import json
from pathlib import Path

TYPES={"object":dict,"array":list,"string":str,"boolean":bool,"integer":int,
       "number":(int,float),"null":type(None)}
META={"type","description","required","properties","items","example","examples","$schema","title",
      "additionalProperties","enum","oneOf","anyOf","allOf","required_fields","fields","files",
      "required_files","artifacts","format","notes","result_json","result_json_fields","schema"}


def check(spec,value,path,errors,review):
    if not isinstance(spec,dict):
        review.append(f"{path}: read the contract's free-form instructions")
        return
    ty=spec.get("type")
    if isinstance(ty,str) and ty in TYPES:
        valid=isinstance(value,TYPES[ty]) and not (ty in ("number","integer") and isinstance(value,bool))
        if not valid:
            errors.append(f"{path}: expected {ty}")
            return
    if "enum" in spec and isinstance(spec["enum"],list) and value not in spec["enum"]:
        errors.append(f"{path}: outside enum")
    for key in ("oneOf","anyOf","allOf","$ref","pattern","minimum","minLength","minItems"):
        if key in spec:
            review.append(f"{path}: check {key} in the original schema")
    if isinstance(value,list) and isinstance(spec.get("items"),dict):
        for i,v in enumerate(value):
            check(spec["items"],v,f"{path}[{i}]",errors,review)
    if isinstance(value,dict):
        req=spec.get("required",[])
        if isinstance(req,list):
            for key in req:
                if isinstance(key,str) and key not in value:
                    errors.append(f"{path}: missing {key}")
        props=spec.get("properties",{})
        if isinstance(props,dict):
            for key,schema in props.items():
                if key in value and isinstance(schema,dict):
                    check(schema,value[key],path+"."+key,errors,review)


def verify(case,result):
    errors,review=[],[]
    if not isinstance(result,dict):
        return ["result.json must be an object"],[]
    if "case_id" not in case or "case_id" not in result or result["case_id"]!=case["case_id"]:
        errors.append("copy the actual case_id exactly, including its type")
    spec=case.get("output_contract")
    if isinstance(spec,dict):
        nested=spec.get("result_json",spec.get("schema",spec))
        check(nested,result,"result",errors,review)
        for container in (spec,nested) if nested is not spec else (spec,):
            if not isinstance(container,dict):
                continue
            for key in ("required_fields","result_json_fields","fields"):
                fields=container.get(key,[])
                if isinstance(fields,dict):
                    fields=list(fields)
                if isinstance(fields,list):
                    for f in fields:
                        name=f if isinstance(f,str) else f.get("name") if isinstance(f,dict) else None
                        if name and (not isinstance(f,dict) or f.get("required",True)) and name not in result:
                            errors.append("result: missing "+name)
            if container and not (set(container)&META):
                review.append("plain key map: inspect whether each entry is required")
                for name in sorted(set(container)-set(result)):
                    review.append("contract key absent from result: "+name)
    elif isinstance(spec,list):
        for f in spec:
            if isinstance(f,str) and f.isidentifier() and f not in result:
                errors.append("result: missing "+f)
            elif not isinstance(f,str) or not f.isidentifier():
                review.append("inspect contract list item: "+str(f)[:120])
    else:
        review.append("inspect task.md and any free-form output_contract manually")
    return list(dict.fromkeys(errors)),list(dict.fromkeys(review))


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("case");p.add_argument("result")
    args=p.parse_args()
    try:
        case,result=[json.loads(Path(f).read_text(encoding="utf-8-sig")) for f in (args.case,args.result)]
        errors,review=verify(case,result)
    except (OSError,ValueError,AttributeError) as exc:
        errors,review=[str(exc)],[]
    print(json.dumps({"errors":errors,"review":review},ensure_ascii=False,indent=2))
    raise SystemExit(bool(errors))

