"""Build source blocks and resolve short quotations by exact Unicode offsets (UTF-8 inputs)."""
import argparse
import hashlib
import json
import re
from pathlib import Path
from xml.etree import ElementTree


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def save(path, data):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def digest(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


class Evidence:
    def __init__(self, sources):
        self.blocks = {}
        self.meta = {}
        for src in sources:
            sid = src["id"]
            if sid in self.meta:
                raise ValueError("duplicate source ID: " + sid)
            self.meta[sid] = src.get("metadata", {})
            for block in src["blocks"]:
                key = (sid, str(block["locator"]))
                if key in self.blocks:
                    raise ValueError("duplicate source locator: " + repr(key))
                self.blocks[key] = block["text"]

    def resolve(self, reference):
        sid, loc, quote = reference["source"], str(reference["locator"]), reference["quote"]
        block = self.blocks.get((sid, loc))
        if block is None or not quote or not quote.strip():
            raise ValueError("missing source, locator or quotation")
        start = reference.get("start")
        if start is None:
            start = block.find(quote)
            if start >= 0 and block.find(quote, start + 1) >= 0:
                raise ValueError("repeated quotation; set zero-based character start")
        if not isinstance(start, int) or start < 0 or block[start:start+len(quote)] != quote:
            raise ValueError("quote mismatch")
        return {"source":sid, "locator":loc, "quote":quote, "start":start,
                "end":start+len(quote), "block_sha256":digest(block)}

    def bind(self, refs):
        if not refs:
            raise ValueError("at least one source quotation is required")
        return [self.resolve(ref) for ref in refs]


def pointer(obj, path):
    if path and not path.startswith("/"):
        raise ValueError("JSON Pointer must start with /")
    for key in path.split("/")[1:]:
        key = key.replace("~1", "/").replace("~0", "~")
        obj = obj[int(key)] if isinstance(obj,list) else obj[key]
    return obj


def read_source(path, sid, ptr, id_key, text_key):
    raw = path.read_bytes()
    text = raw.decode("utf-8-sig")
    metadata = {"filename":path.name,"file_sha256":hashlib.sha256(raw).hexdigest()}
    if path.suffix.lower() in (".xml", ".nxml"):
        root = ElementTree.fromstring(text)
        for el in root.iter():
            el.tag = el.tag.rsplit("}", 1)[-1]
        blocks = [{"locator":p.get("id") or f"p[{i}]", "text":"".join(p.itertext())}
                  for i,p in enumerate(root.iter("p"),1)]
    elif ptr is not None:
        records = pointer(json.loads(text), ptr)
        if not isinstance(records,list):
            raise ValueError("select an array of paragraphs with --pointer")
        blocks = [{"locator":str(item[id_key]), "text":item[text_key]} for item in records]
    else:
        blocks = [{"locator":f"L{i}", "text":s} for i,s in enumerate(text.splitlines(),1) if s.strip()]
    if not blocks or any(not isinstance(b["text"],str) for b in blocks):
        raise ValueError("source contains no textual blocks")
    return {"id":sid,"metadata":metadata,"blocks":blocks}


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Index one UTF-8 source. Existing corpus retains other source IDs.")
    ap.add_argument("source_id")
    ap.add_argument("file",type=Path)
    ap.add_argument("corpus",type=Path)
    ap.add_argument("--pointer",help="JSON Pointer to paragraph array; empty string selects root")
    ap.add_argument("--id-key",default="paragraph_id")
    ap.add_argument("--text-key",default="text")
    args = ap.parse_args()
    src = read_source(args.file,args.source_id,args.pointer,args.id_key,args.text_key)
    corpus = load(args.corpus) if args.corpus.exists() else []
    corpus = [s for s in corpus if s["id"] != args.source_id] + [src]
    Evidence(corpus)
    save(args.corpus,corpus)

