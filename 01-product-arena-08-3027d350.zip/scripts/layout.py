"""PDF page geometry in unrotated top-left points. Only extract_fitz needs PyMuPDF."""
import bisect
import collections
import re
import statistics
import unicodedata


def _mid(line):
    box = line["bbox"]
    return (box[1] + box[3]) / 2


def _gutter(lines, left, right):
    """Require parallel text on both sides, not just whitespace on one side."""
    width = right - left
    if len(lines) < 4 or width < 40:
        return None
    tall = statistics.median(max(1, r["bbox"][3] - r["bbox"][1]) for r in lines)
    best, choice = (), None
    for step in range(20, 81, 2):
        x = left + width * step / 100
        pad = max(1.2, width * .006)
        a = [r for r in lines if r["bbox"][2] <= x - pad and r["bbox"][2] - r["bbox"][0] >= width * .085]
        b = [r for r in lines if r["bbox"][0] >= x + pad and r["bbox"][2] - r["bbox"][0] >= width * .085]
        if min(len(a), len(b)) < 2:
            continue
        ys = sorted(_mid(r) for r in b)
        pairs = set()
        for r in a:
            y = _mid(r)
            n = bisect.bisect_left(ys, y)
            for j in (n - 1, n):
                if 0 <= j < len(ys) and abs(ys[j] - y) < tall * 1.7:
                    pairs.add(j)
        if len(pairs) < 2:
            continue
        crossing = sum(r["bbox"][0] < x < r["bbox"][2] for r in lines)
        gap = min(x - max(r["bbox"][2] for r in a), min(r["bbox"][0] for r in b) - x)
        score = (len(pairs) / (1 + .08 * crossing), min(len(a), len(b)), gap, -abs(step - 50))
        if score > best:
            best, choice = score, x
    return choice


def _flow(lines, left, right, depth=0):
    plain = sorted(lines, key=lambda r: (round(_mid(r), 1), r["bbox"][0]))
    gutter = _gutter(lines, left, right) if depth < 2 else None
    if gutter is None:
        return plain
    # Full-width lines delimit vertical bands. This keeps a full-width table
    # or new section between the preceding and following sets of columns.
    spans = [r for r in plain if r["bbox"][0] < gutter < r["bbox"][2]]
    levels = [_mid(r) for r in spans]
    bands = [([], []) for _ in range(len(levels) + 1)]
    for r in plain:
        x0, _, x1, _ = r["bbox"]
        if x0 < gutter < x1:
            continue
        band = bisect.bisect_right(levels, _mid(r))
        bands[band][int(x0 >= gutter)].append(r)
    result = []
    for i, (a, b) in enumerate(bands):
        for group, lo, hi in ((a, left, gutter), (b, gutter, right)):
            for r in group:
                r["_column_x"] = lo
            result.extend(_flow(group, lo, hi, depth + 1))
        if i < len(spans):
            result.append(spans[i])
    return result


def order_page(lines, width, height, page_number):
    """Assign stable per-page IDs, reading order, and locally inferred columns."""
    rows = [dict(r) for r in lines if str(r.get("text", "")).strip()]
    ordered = _flow(rows, 0, width)
    starts = sorted({r["_column_x"] for r in ordered if "_column_x" in r})
    for index, r in enumerate(ordered, 1):
        start = r.pop("_column_x", None)
        r.update(id=f"p{page_number}-l{index:04d}", order=index, page=page_number,
                 column=(starts.index(start) + 1 if start is not None else 0))
    return ordered


def mark_running_margins(pages):
    """Mark repeated marginal text without discarding evidence or footnotes."""
    occurrences = collections.defaultdict(list)
    for i, page in enumerate(pages):
        for line in page["lines"]:
            y = _mid(line) / max(1, page["height"])
            if .085 <= y <= .925:
                continue
            raw = unicodedata.normalize("NFKC", line["text"]).casefold().strip()
            if len(raw) > 150:
                continue
            key = re.sub(r"\s+", " ", raw)
            # Normalize standalone folios, but preserve numbers inside assertions.
            key = re.sub(r"^(?:(?:page|p\.)\s*)?[-–—]?\s*\d+\s*[-–—]?$", "{folio}", key)
            band = "running_header" if y < .5 else "running_footer"
            occurrences[(band, key)].append((i, y, line))
    for (role, _), hits in occurrences.items():
        for i, y, line in hits:
            if any(j != i and abs(y - other_y) < .015 for j, other_y, _ in hits):
                line.setdefault("role", role)
    return pages


def extract_fitz(pdf_path):
    """One record per physical page. Empty pages remain present for OCR fallback."""
    try:
        import pymupdf as fitz
    except ImportError:
        import fitz
    pages = []
    with fitz.open(pdf_path) as doc:
        for page in doc:
            words = collections.defaultdict(list)
            for x0, y0, x1, y1, text, block_id, line_no, *_ in page.get_text("words"):
                words[block_id, line_no].append({"text": text, "bbox": [x0, y0, x1, y1]})
            rows = []
            block_data = page.get_text("dict", flags=fitz.TEXTFLAGS_DICT & ~fitz.TEXT_PRESERVE_IMAGES)
            for block in block_data["blocks"]:
                for i, line in enumerate(block.get("lines", [])):
                    spans = [{key: span[key] for key in ("text", "bbox", "size", "flags", "font", "origin") if key in span}
                             for span in line["spans"]]
                    rows.append({"text": "".join(s["text"] for s in spans), "bbox": list(line["bbox"]),
                                 "spans": spans, "words": words[block["number"], i], "direction": list(line["dir"]),
                                 "source": "pymupdf", "block": block["number"]})
            width, height = page.cropbox.width, page.cropbox.height
            number = page.number + 1
            pages.append({"page": number, "width": width, "height": height, "rotation": page.rotation,
                          "lines": order_page(rows, width, height, number)})
    return mark_running_margins(pages)
