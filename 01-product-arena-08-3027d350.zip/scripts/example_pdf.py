"""Generate a one-page synthetic PDF. No third-party libraries required."""
import sys
from pathlib import Path


def write(path):
    content=b"BT /F1 16 Tf 50 735 Td (Layout example) Tj 0 -35 Td /F1 11 Tf (Visible text provides a verifiable page anchor.) Tj ET"
    objs=[b"<< /Type /Catalog /Pages 2 0 R >>", b"<< /Type /Pages /Count 1 /Kids [3 0 R] >>",
          b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 600 800] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>",
          b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
          b"<< /Length "+str(len(content)).encode()+b" >>\nstream\n"+content+b"\nendstream"]
    buf=bytearray(b"%PDF-1.4\n"); offsets=[]
    for i,obj in enumerate(objs,1):
        offsets.append(len(buf));buf.extend(f"{i} 0 obj\n".encode()+obj+b"\nendobj\n")
    xref=len(buf);buf.extend(f"xref\n0 {len(objs)+1}\n0000000000 65535 f \n".encode())
    for offset in offsets: buf.extend(f"{offset:010d} 00000 n \n".encode())
    buf.extend(f"trailer\n<< /Size {len(objs)+1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n".encode())
    Path(path).write_bytes(buf)


if __name__=="__main__":
    write(sys.argv[1])

