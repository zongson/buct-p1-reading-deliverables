"""Recover page-local object evidence. Geometry uses unrotated PDF points, top-left origin."""
import math
import re
from statistics import median


CAPTION = re.compile(r"^\s*(?P<kind>supplementary\s+(?:fig(?:ure)?|table)|fig(?:ure)?|table|图|圖|表)\.?\s*(?P<num>(?:[A-Z]?\d+[A-Za-z]?|[IVXLCDM]+))(?![A-Za-z0-9])", re.I)
PROSE = re.compile(r"^\s+(?:shows?|lists?|demonstrates?|depicts?|summari[sz]es?|presents?|is|was|illustrates?)\b", re.I)
TAG = re.compile(r"[（(]([A-Z]?\d+(?:\.\d+)*[a-z]?)[）)]\s*$", re.I)
OPS = re.compile(r"[=≈≡≠≤≥∝∫∑∏∂√∞±×÷∇∈∉≃]")


def box(value):
    if value is None:
        return None
    values = [round(float(x), 3) for x in value]
    if len(values) == 4 and all(map(math.isfinite, values)) and values[2] >= values[0] and values[3] >= values[1]:
        return values
    return None


def union(boxes):
    return [min(b[0] for b in boxes), min(b[1] for b in boxes),
            max(b[2] for b in boxes), max(b[3] for b in boxes)]


def nearest(captions, rect):
    candidates = []
    for cap in captions:
        b = cap["bbox"]
        if not rect or not b or min(rect[2], b[2]) <= max(rect[0], b[0]):
            continue
        gap = max(b[1] - rect[3], rect[1] - b[3], 0)
        if gap <= 75:
            candidates.append((gap, cap["id"]))
    candidates.sort()
    if candidates and (len(candidates) == 1 or candidates[1][0] - candidates[0][0] >= 4):
        return candidates[0][1]
    return None


def aligned_rows(caption, lines):
    """Conservative borderless-table candidate immediately beneath a table label."""
    cb = caption["bbox"]
    if cb is None:
        return []
    parts = []
    for line in lines:
        for w in line.get("words", []) or [line]:
            b = box(w.get("bbox"))
            if b and cb[3] - 1 <= b[1] <= cb[3] + 245 and b[0] >= cb[0] - 25:
                parts.append((b, w["text"]))
    rows = []
    for b, text in sorted(parts, key=lambda p: ((p[0][1] + p[0][3]) / 2, p[0][0])):
        mid = (b[1] + b[3]) / 2
        if not rows or mid - rows[-1][0] > max(2.0, (b[3] - b[1]) * .38):
            rows.append((mid, []))
        rows[-1][1].append((b, text))
    observed = []
    for _, row in rows:
        tokens = sorted(row, key=lambda p: p[0][0])
        h = median(max(1, b[3] - b[1]) for b, _ in tokens)
        chunks = []
        for b, text in tokens:
            if chunks and b[0] - chunks[-1]["bbox"][2] < max(12, 1.4 * h):
                chunks[-1]["text"] += " " + text
                chunks[-1]["bbox"] = union([b, chunks[-1]["bbox"]])
            else:
                chunks.append({"text": text, "bbox": b})
        if len(chunks) < 2 or len(chunks) > 16:
            if observed:
                break
            continue
        if observed:
            prev = observed[-1]
            if len(chunks) != len(prev) or chunks[0]["bbox"][1] - prev[0]["bbox"][3] > 2 * h:
                break
            if any(min(abs(a["bbox"][i]-b["bbox"][i]) for i in (0,2)) > max(10,h)
                   for a,b in zip(chunks,prev)):
                break
        observed.append(chunks)
    if len(observed) < 3 or not any(re.search(r"\d", cell["text"]) for row in observed[1:] for cell in row):
        return []
    return observed


def rule_table(page, caption):
    """Recover open-sided scientific tables bounded by horizontal rules (booktabs)."""
    cap = caption["bbox"]
    if not cap:
        return None
    rules = []
    for path in page.get_drawings():
        r = path["rect"]
        if r.height <= 1.5 and r.width >= 24:
            rules.append((r.y0, r.x0, r.x1))
    starts = [r for r in rules if 0 <= r[0]-cap[3] <= 54 and
              r[2]-r[1] >= 65 and min(cap[2],r[2]) > max(cap[0],r[1])]
    if not starts:
        return None
    top, left, right = min(starts)
    broad = sorted({round(y,2) for y,x0,x1 in rules
                    if y >= top-0.1 and abs(x0-left)<3 and abs(x1-right)<3})
    if len(broad)<2:
        return None
    # A later table can share both margins. Stop at the first gap in textual baselines.
    bottom = broad[-1]
    fragments = []
    for block in page.get_text("dict",clip=(left-1,top-3,right+1,bottom+3))["blocks"]:
        for line in block.get("lines",[]):
            spans = line["spans"]
            text = "".join(s["text"] for s in spans).strip()
            rect = box(line["bbox"])
            if not text or line.get("dir",(1,0))[0] < .95 or not (top <= rect[3] <= bottom+2):
                continue
            scripts = [{"text":s["text"],"bbox":box(s["bbox"])} for s in spans
                       if s["flags"] & 1 and s["text"].strip()]
            fragments.append({"text":text,"bbox":rect,"superscript_spans":scripts})
    if not fragments:
        return None
    height = median(c["bbox"][3]-c["bbox"][1] for c in fragments)
    bands = []
    for c in sorted(fragments,key=lambda c:c["bbox"][3]):
        y = c["bbox"][3]
        if bands and y-bands[-1][0] > max(20,2.1*height):
            bottom = min((r for r in broad if r >= bands[-1][0]-2),default=bottom)
            break
        if not bands or y-bands[-1][0] > max(2.2,.30*height):
            bands.append((y,[]))
        bands[-1][1].append(c)
    if len(bands)<3 or bottom-top<height*2:
        return None
    head_end = broad[1] if len(broad)>2 else top
    body = [sorted(row,key=lambda c:c["bbox"][0]) for y,row in bands if y>head_end+1]
    # Infer leaf columns only from a repeated dense row pattern. Empty cells stay empty.
    counts = [len(row) for row in body]
    supported = [n for n in counts if 2<=n<=24 and counts.count(n)>=2]
    if not supported:
        return None
    ncols = max(supported)
    dense = [row for row in body if len(row)==ncols]
    mids = [median((row[j]["bbox"][0]+row[j]["bbox"][2])/2 for row in dense)
            for j in range(ncols)]
    if any(b-a<6 for a,b in zip(mids,mids[1:])):
        return None
    cuts = [(median(r[j]["bbox"][2] for r in dense)+median(r[j+1]["bbox"][0] for r in dense))/2
            for j in range(ncols-1)]
    rows, headings = [], []
    for y, band in bands:
        is_header = y <= head_end+1
        row = [{"text":None,"bbox":None} for _ in mids]
        for c in sorted(band,key=lambda c:c["bbox"][0]):
            b = c["bbox"]
            center=(b[0]+b[2])/2
            col=sum(center>cut for cut in cuts)
            cell = dict(c)
            # Group rules below a centered header are direct evidence of the columns it spans.
            subrules=[(x0,x1) for yy,x0,x1 in rules if is_header and
                      0<=yy-b[3]<=.85*height and x0<=center<=x1 and x1-x0<(right-left)*.9]
            spans=[]
            if subrules:
                x0,x1=min(subrules,key=lambda pair:pair[1]-pair[0])
                spans=[j for j,x in enumerate(mids) if x0<=x<=x1]
            if not spans:
                spans=[j for j,x in enumerate(mids) if b[0]<=x<=b[2]]
            # A value printed centered between adjacent leaf columns can be shared;
            # retain its exact bounding box and both candidate columns, never duplicate it.
            if not spans:
                spans=[j for j in range(len(mids)-1)
                       if b[0]<cuts[j]<b[2] and abs(center-cuts[j])<=.25*(mids[j+1]-mids[j])]
                spans=[spans[0],spans[0]+1] if spans else [col]
            if len(spans)>1:
                cell["column_span_candidate"]=[min(spans)+1,max(spans)+1]
                col=min(spans)
            if row[col]["text"] is not None:
                return None  # conflicting logical slots; fall back to a less confident method
            row[col]=cell
        rows.append(row)
        if is_header:
            headings.append(len(rows))
    return {"bbox":box((left,top,right,bottom)), "rows":rows, "header_rows":headings,
            "column_centers":[round(x,2) for x in mids],
            "method":"horizontal rules and aligned source text; null = unobserved; span candidates require visual review"}


def plot_grid(rows, rect, table_cap, fig_caps, page):
    """Grid-like vector figures often have many blank cells and text only on axis rows."""
    if table_cap:
        return False
    n = max(map(len,rows))
    occupied = [sum(bool(c["text"] and c["text"].strip()) for c in row) for row in rows]
    density = sum(occupied)/(n*len(rows))
    if n<6 or density>.55:
        return False
    if density<.29 and (nearest(fig_caps,rect) or sum(x==0 for x in occupied)>=len(rows)/2):
        return True
    if fig_caps:
        # Axis labels in an attention plot or heat map may be split across every
        # grid boundary, producing superficially non-empty cells. Inspect text direction.
        labels = [l for b in page.get_text("dict",clip=rect)["blocks"] for l in b.get("lines",[])]
        rotated = sum(abs(l.get("dir",(1,0))[1])>.75 for l in labels)
        if len(labels)>=5 and rotated>=.6*len(labels):
            return True
    return False


def extract_objects(page_number, lines, page=None):
    """Accept line dictionaries from fitz, OCR or Poppler. No semantic labels are invented."""
    lines = list(lines)
    result = {key: [] for key in ("tables", "figures", "equations", "captions", "warnings")}

    def add(key, rect, **data):
        ident = "p%d-%s-%d" % (page_number, key, len(result[key])+1)
        item = {"id": ident, "page": page_number, "bbox": rect, **data}
        result[key].append(item)
        return item

    for line in lines:
        text = line.get("text", "").strip()
        rect = box(line.get("bbox"))
        match = CAPTION.match(text)
        if match and not PROSE.match(text[match.end():]):
            kind = "table" if re.search(r"table|表", match["kind"], re.I) else "figure"
            add("captions", rect, kind=kind, label=match[0].strip(), text=text)
            continue
        tag = TAG.search(text)
        long_words = re.findall(r"\b[A-Za-z]{4,}\b",text)
        if OPS.search(text) and len(text) < 320 and (len(long_words) <= 3 or tag):
            scripts = [{"text":s.get("text",""),"bbox":box(s.get("bbox"))}
                       for s in line.get("spans", []) if int(s.get("flags",0)) & 1]
            add("equations",rect,text=text,number=tag[1] if tag else None,
                superscript_spans=scripts,method="operator-bearing line; visual verification required")

    table_caps = [c for c in result["captions"] if c["kind"] == "table"]
    fig_caps = [c for c in result["captions"] if c["kind"] == "figure"]
    if page is not None:
        try:
            for table in page.find_tables().tables:
                values = table.extract()
                rows = [[{"text":v,"bbox":box(cell)} for v,cell in zip(row,meta.cells)]
                        for row,meta in zip(values,table.rows)]
                if len(rows) >= 2 and max(map(len,rows),default=0) >= 2:
                    b = box(table.bbox)
                    cap_id = nearest(table_caps,b)
                    if plot_grid(rows,b,cap_id,fig_caps,page):
                        add("figures",b,kind="vector_grid_candidate",caption_id=nearest(fig_caps,b),
                            method="sparse grid with axis-like text; inspect the rendered artwork")
                        continue
                    add("tables",b,rows=rows,caption_id=cap_id,
                        method="ruled cell grid; null geometry means no separate cell")
        except (AttributeError, RuntimeError, ValueError, TypeError, IndexError) as exc:
            result["warnings"].append("Ruled-table detection unavailable: "+type(exc).__name__)
        try:
            pb = page.cropbox
            for img in page.get_image_info():
                b = box(img["bbox"])
                if b and (b[2]-b[0])*(b[3]-b[1]) < .86 * pb.width * pb.height:
                    add("figures",b,kind="raster_region",caption_id=nearest(fig_caps,b),
                        pixel_size=[img["width"],img["height"]],method="embedded bitmap; may be decorative")
        except (AttributeError, RuntimeError, ValueError) as exc:
            result["warnings"].append("Image inventory unavailable: "+type(exc).__name__)
    for cap in table_caps:
        if not any(t["caption_id"] == cap["id"] for t in result["tables"]):
            if page is not None:
                try:
                    ruled=rule_table(page,cap)
                    if ruled:
                        add("tables",ruled.pop("bbox"),caption_id=cap["id"],**ruled)
                        continue
                except (RuntimeError, ValueError, TypeError, IndexError, AttributeError) as exc:
                    result["warnings"].append("Horizontal-rule table inspection unavailable: "+type(exc).__name__)
            rows = aligned_rows(cap,lines)
            rect = union([c["bbox"] for row in rows for c in row]) if rows else cap["bbox"]
            add("tables",rect,rows=rows,caption_id=cap["id"],
                method="aligned text candidate; inspect columns and units" if rows else "caption only; grid unresolved")
    for cap in fig_caps:
        if not any(f["caption_id"] == cap["id"] for f in result["figures"]):
            add("figures",cap["bbox"],kind="caption_only",caption_id=cap["id"],
                method="caption location; artwork bounds unknown, inspect page render")
    return result
