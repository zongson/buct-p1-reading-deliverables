"""Extract page-local evidence. Python 3.9+, PyMuPDF or Poppler; optional Tesseract."""
import argparse
import csv
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path

from layout import extract_fitz, mark_running_margins, order_page
from objects_pdf import extract_objects


def run(args, timeout=65):
    proc = subprocess.run(list(map(str, args)), capture_output=True, timeout=timeout)
    if proc.returncode:
        raise RuntimeError(proc.stderr.decode("utf-8", "replace").strip()[:350] or str(proc.returncode))
    return proc.stdout


def bbox(node):
    return [float(node.attrib[k]) for k in ("xMin", "yMin", "xMax", "yMax")]


def poppler(pdf):
    xml = ET.fromstring(run(["pdftotext", "-enc", "UTF-8", "-bbox-layout", pdf, "-"], 150))
    pages = []
    for number, elem in enumerate(xml.findall(".//{*}page"), 1):
        width, height = float(elem.get("width")), float(elem.get("height"))
        lines = []
        for line in elem.findall(".//{*}line"):
            words = [{"text": w.text or "", "bbox": bbox(w)} for w in line.findall("{*}word")]
            if words:
                lines.append({"text": " ".join(w["text"] for w in words), "bbox": bbox(line),
                              "words": words, "source": "poppler"})
        pages.append(dict(width=width, height=height, lines=order_page(lines, width, height, number)))
    return pages


def ocr(pdf, page, number, langs, tmp):
    from struct import unpack
    stem = tmp / ("p%d" % number)
    run(["pdftoppm", "-f", number, "-l", number, "-r", 230, "-singlefile", "-gray", "-png", pdf, stem])
    image = stem.with_suffix(".png")
    with image.open("rb") as stream:
        pxw, pxh = unpack(">II", stream.read(24)[16:])
    sx, sy = page["width"]/pxw, page["height"]/pxh
    data = run(["tesseract", image, "stdout", "-l", langs, "--psm", "3", "tsv"]).decode("utf-8", "replace")
    grouped = {}
    for row in csv.DictReader(io.StringIO(data), delimiter="\t", quoting=csv.QUOTE_NONE):
        if row["level"] != "5" or not (row.get("text") or "").strip():
            continue
        x, y, w, h = [int(row[k]) for k in ("left", "top", "width", "height")]
        key = tuple(row[k] for k in ("block_num", "par_num", "line_num"))
        grouped.setdefault(key, []).append({"text": row["text"], "bbox": [x*sx,y*sy,(x+w)*sx,(y+h)*sy],
                                          "confidence": float(row["conf"])})
    lines = []
    for words in grouped.values():
        coords = list(zip(*(w["bbox"] for w in words)))
        lines.append({"text": " ".join(w["text"] for w in words),
                      "bbox": [min(coords[0]),min(coords[1]),max(coords[2]),max(coords[3])],
                      "source": "tesseract", "words": words,
                      "min_word_confidence": min(w["confidence"] for w in words)})
    return lines


def center_overlaps(one, other):
    x0,y0,x1,y1 = one
    a,b,c,d = other
    return a-1 <= (x0+x1)/2 <= c+1 and b-1 <= (y0+y1)/2 <= d+1


def integrated_ocr(page, lang):
    textpage = page.get_textpage_ocr(language=lang, dpi=230, full=True,
                                     tessdata=os.environ.get("TESSDATA_PREFIX") or None)
    data = page.get_text("dict", textpage=textpage)
    return [{"text": "".join(s["text"] for s in l["spans"]), "bbox": list(l["bbox"]),
             "source": "mupdf-tesseract", "needs_visual_check": True}
            for block in data["blocks"] for l in block.get("lines", [])]


def extract(pdf, backend, lang, force_pages):
    issues, changes = [], []
    doc = None
    if backend != "poppler":
        try:
            try:
                import pymupdf as fitz
            except ImportError:
                import fitz
            pages = extract_fitz(str(pdf))
            doc = fitz.open(pdf)
        except Exception as exc:
            if backend == "fitz":
                raise
            changes.append("Native layout backend unavailable; used Poppler: " + str(exc)[:180])
    if doc is None:
        pages = poppler(pdf)
    method = "pymupdf" if doc is not None else "poppler"
    ocr_available = shutil.which("pdftoppm") and shutil.which("tesseract")
    with tempfile.TemporaryDirectory() as tmp:
        for i, page in enumerate(pages, 1):
            native = page["lines"]
            txt = "".join(l["text"] for l in native)
            damaged = txt.count("\ufffd") > max(1,len(txt)*.03)
            contains_scan = False
            if doc is not None:
                area = max(1, page["width"]*page["height"])
                boxes = (im["bbox"] for im in doc[i-1].get_image_info())
                large_image = any((x1-x0)*(y1-y0)>.65*area for x0,y0,x1,y1 in boxes)
                native_area = sum((l["bbox"][2]-l["bbox"][0])*(l["bbox"][3]-l["bbox"][1]) for l in native)
                contains_scan = large_image and native_area < .09*area
            # Sparse native overlays (including running heads) can conceal an entire scanned page.
            if i in force_pages or len(txt.strip()) < 45 or damaged or contains_scan:
                if ocr_available or (doc is not None and os.environ.get("TESSDATA_PREFIX")):
                    try:
                        if doc is not None and (not ocr_available or page.get("rotation", 0)):
                            raw = integrated_ocr(doc[i-1], lang)
                        else:
                            raw = ocr(pdf, page, i, lang, Path(tmp))
                        # Prefer native glyphs at overlaps, except lines with damaged character maps.
                        keep = [l for l in native if "\ufffd" not in l["text"]]
                        additional = [l for l in raw if not any(center_overlaps(l["bbox"], k["bbox"]) for k in keep)]
                        if raw:
                            remainder = [l for l in native if "\ufffd" in l["text"] and
                                         not any(center_overlaps(l["bbox"], x["bbox"]) for x in raw)]
                            page["lines"] = order_page(keep+additional+remainder,page["width"],page["height"],i)
                            if damaged:
                                page["original_damaged_lines"] = [l for l in native if "\ufffd" in l["text"]]
                            changes.append(f"p{i}: OCR inspected, {len(additional)} supplementary lines")
                        else:
                            issues.append(f"p{i}: OCR returned no words; inspect page image")
                    except Exception as exc:
                        issues.append(f"p{i}: OCR unavailable or failed: {exc}")
                else:
                    issues.append(f"p{i}: sparse or damaged text; OCR unavailable; inspect page image")
            for line in page["lines"]:
                if line.get("min_word_confidence",100)<60 or "\ufffd" in line["text"]:
                    line["needs_visual_check"] = True
                    issues.append(f'{line["id"]}: check glyphs against rendered page')
            try:
                page["objects"] = extract_objects(i, page["lines"],doc[i-1] if doc else None)
            except Exception as exc:
                issues.append(f"p{i}: object analysis incomplete: {exc}")
            page["page"] = i
    if doc is not None:
        doc.close()
    mark_running_margins(pages)
    return {"status": "partial" if issues or not pages else "extracted",
            "input": pdf.name,"sha256":hashlib.sha256(pdf.read_bytes()).hexdigest(),
            "backend":method,"coordinates":"PDF points, top-left; physical page index starts at 1",
            "pages":pages,"review":issues,"changes":changes}


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("input",type=Path)
    ap.add_argument("output",type=Path)
    ap.add_argument("--backend",choices=["auto","fitz","poppler"],default="auto")
    ap.add_argument("--ocr-lang",default="eng",help="installed Tesseract language codes, e.g. chi_sim+eng")
    ap.add_argument("--ocr-pages",type=int,nargs="*",default=[],help="also inspect these 1-based hybrid pages")
    args=ap.parse_args()
    try:
        data=extract(args.input.resolve(),args.backend,args.ocr_lang,set(args.ocr_pages))
    except Exception as exc:
        data={"input":args.input.name,"status":"failed","pages":[],"review":[str(exc)[:500]]}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    tmp=args.output.with_suffix(args.output.suffix+".tmp")
    tmp.write_text(json.dumps(data,ensure_ascii=False),encoding="utf-8")
    tmp.replace(args.output)
    print(json.dumps({"status":data["status"],"pages":len(data["pages"]),"review":len(data["review"])}))
    return int(data["status"]=="failed")


if __name__=="__main__":
    raise SystemExit(main())

