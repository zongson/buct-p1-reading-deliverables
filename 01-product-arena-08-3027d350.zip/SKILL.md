---
name: parse-scientific-pdf
description: Parse an original scientific PDF into ordered, page-anchored text, section structure, tables, figures and equation evidence. Handle mixed columns, scans and partial extraction.
---

# 从 PDF 到可回查的结构

先打开 /input/case.json 和随案 task.md，记录原始 case_id、要求的页段、优先结构、输出语言及 output_contract。以实际 PDF 为来源。把中间索引写入 /app/work，把可用产物写入 /app/output；即使个别页失败也先保存已核实的页。独立使用时路径可任意指定。

## 一次提取，按风险回看

1. 调用 `python /skills/weekly-skill/scripts/parse_pdf.py INPUT.pdf /app/work/index.json`。默认使用 PyMuPDF；未安装时自动使用 Poppler。命令返回状态与页数。巨大文档用 Python 按页或按关键词读取索引，避免把全部 JSON 放进上下文。
2. 对照页数、页码标签、页宽和方向。物理页从 1 起。抽样看首尾页以及每个版式变化处。列内从上到下，遇跨栏标题/通栏图表先结束上一带。页眉和页脚保留在 index 中并标记；脚注与正文分别输出。摘要、标题、作者/单位、编号章节与参考文献按原版面建立层级。跨页续段保留两个页锚；仅在末行断词且下页首词确定接续时写规范化读法，同时保留原字符串。
3. 对每张有题注但没有行列结构的表、每个上下标难辨的公式、大图夹少量文字的页面、每个乱码或低置信词，定向渲染，例如 `pdftoppm -f 3 -l 3 -r 180 -singlefile -png INPUT.pdf /app/work/p3`。看实际图像再补边界、角色及字符。合并单元格记录行列范围和空位；跨页表只有在表号/续表标记、表头、列数和单位都相符时连接，保留每段原始页号。数字、负号、希腊字母和上下标逐个对图；识别不全时保留裁图位置或原字符串。图注锚不能充当图像边界。
4. 没有文字层时会调用 pdftoppm + tesseract。混合页可用 `--ocr-pages 2 4 --ocr-lang chi_sim+eng` 显式复查；用 `tesseract --list-langs` 确认语言包。仅将新识别区域并入原层。OCR 的 min_word_confidence 是引擎读数。旋转页的原生坐标为未旋转页面坐标；对旋转页优先用渲染后同一坐标系复读。若存在旋转和混合 OCR，重新使用 `--backend poppler` 独立对齐后再引用。
5. 每项关键结果绑定原文件、物理页以及行 ID，表、图或公式再附对象 ID 与 bbox。坐标单位为 PDF point。依据案例契约写 /app/output/result.json，保留原 case_id 与全部要求字段，注明运行状态、证据、未读部分和修订记录。如果要求完整可复用产物，再交对应的 Markdown/JSON/表格，不要只引用临时文件。对原文证据与人工判定分开标注。
6. 终检按页核对非重复行数、表头/行尾、每条关键定位、首末参考文献。核实有结构元素的每一页；双栏或跨页最容易把内容配错。发现缺失就定点重跑。平台进行正式对照实验；本地记录只报告真实测量的时间和校验结果。

## 依赖与最小示例

Python 3.9+；原生路径已用 PyMuPDF 1.27.1 测试，可在有安装权限的环境使用 `python -m pip install pymupdf`。无需安装时可使用比赛镜像内的 Poppler 命令；OCR 还需 Tesseract 及对应语言数据。辅助文件均位于 scripts/。已知边界包括纵排文献、复杂无框表、矢量图、交错的三栏图和开放密码未知的文件。遇到未读区域，应记录页面与下一步核验所需材料。

运行 `python scripts/example_pdf.py demo.pdf` 后运行 `python scripts/parse_pdf.py demo.pdf demo.json`。示例 PDF 由标准库生成，内容是虚构的教学短句。示意摘录：第 1 页第一行含有 “Layout example”，对应页内行锚和四个坐标。不同后端的数值边界可以稍有差异。查看 JSON 的 pages[].lines 与 pages[].objects，并按实际案例要求汇总。


## 案例合同复核

运行 `python /skills/weekly-skill/scripts/verify_contract.py /input/case.json /app/output/result.json`。修复 errors，按原题逐条确认 review 和产物路径。此工具检查能明确识别的 JSON 契约与 case_id。

遇到本题的典型边界输入时，可参考 [专项核对卡](references/field-check.md)，按其中的示例区分自动检查与需要回原文判定的部分。
