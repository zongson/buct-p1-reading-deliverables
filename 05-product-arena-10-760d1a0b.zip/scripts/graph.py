"""Build a source-scoped directed evidence graph, verify merge decisions, execute queries."""
import argparse
import json
from collections import defaultdict
from pathlib import Path
from evidence import Evidence, digest, load, save

KINDS = {"person","material","method","task","metric","finding","sample","dataset","condition","quantity","concept","instrument","other"}
REL = {"uses","measures","compares_with","outperforms","supports","contradicts","evaluates","reports","part_of","associated_with","depends_on","other"}
INSTANCE = {"sample","dataset","instrument","person"}


def key(*fields):
    return digest(json.dumps(fields,ensure_ascii=False))[:20]


def run(corpus, draft):
    evidence = Evidence(corpus)
    nodes, edges, merges, queries, review = {}, {}, [], [], []
    by_ref, parent = {}, {}
    def canonical(nid):
        while nid != parent[nid]:
            nid = parent[nid]
        return nid
    for i,n in enumerate(draft.get("nodes",[]),1):
        try:
            sid, local = n["source"], n["local"]
            nid = "n-"+key(sid,local)
            if not n["label"].strip() or n["type"] not in KINDS or (sid,local) in by_ref:
                raise ValueError("blank label, unrecognized type or duplicate local ID")
            refs=evidence.bind(n["evidence"])
            if {r["source"] for r in refs} != {sid}:
                raise ValueError("node mention belongs to another source")
            names=[n["label"]]+n.get("aliases",[])
            if not any(name and name.casefold() in ref["quote"].casefold() for name in names for ref in refs):
                raise ValueError("label or verbatim alias must be anchored to a mention")
            nodes[nid]={"id":nid,"source":sid,"local":local,"label":n["label"],"type":n["type"],"aliases":n.get("aliases",[]),"evidence":refs}
            by_ref[(sid,local)] = parent[nid] = nid
        except (KeyError,ValueError,TypeError,AttributeError) as exc:
            review.append({"node":i,"reason":str(exc)})
    for i,m in enumerate(draft.get("alignments",[]),1):
        try:
            a,b = [by_ref[tuple(m[k])] for k in ("keep","candidate")]
            reason=m["reason"].strip()
            if a==b or not reason or m["decision"] not in {"merge","keep_separate","unresolved"}:
                raise ValueError("invalid alignment decision")
            refs=evidence.bind(m["evidence"])
            if not {nodes[a]["source"],nodes[b]["source"]}.issubset({r["source"] for r in refs}):
                raise ValueError("alignment must cite both sources")
            if m["decision"]=="merge":
                if nodes[a]["type"]!=nodes[b]["type"]:
                    raise ValueError("cannot merge incompatible entity types")
                if nodes[a]["type"] in INSTANCE and not m.get("shared_identifier"):
                    raise ValueError("an instance merge requires a verified common identifier")
                if m.get("shared_identifier") and not all(any(m["shared_identifier"] in r["quote"] and r["source"]==s for r in refs) for s in (nodes[a]["source"],nodes[b]["source"])):
                    raise ValueError("shared identifier absent from a cited source")
                parent[canonical(b)] = canonical(a)
            merges.append({"a":a,"b":b,"decision":m["decision"],"reason":reason,"evidence":refs})
        except (KeyError,TypeError,ValueError,AttributeError) as exc:
            review.append({"alignment":i,"reason":str(exc)})
    for nid,n in nodes.items():
        n["canonical"]=canonical(nid)
    for i,e in enumerate(draft.get("edges",[]),1):
        try:
            a,b = [by_ref[tuple(e[k])] for k in ("from","to")]
            rel=e["relation"]
            stance=e["stance"]
            if rel not in REL or stance not in {"observed","negated","hypothesis","cited","inferred","uncertain"}:
                raise ValueError("unknown relation or stance")
            if rel=="other" and not e.get("relation_label"):
                raise ValueError("supply relation_label for an unlisted relation")
            refs=evidence.bind(e["evidence"])
            sid=e["source"]
            if {r["source"] for r in refs}!={sid} or nodes[a]["source"]!=sid or nodes[b]["source"]!=sid:
                raise ValueError("use source-local endpoints; link papers by explicit entity alignment")
            conditions=e["conditions"]
            eid="e-"+key(sid,a,rel,e.get("relation_label",""),b,stance,conditions)
            record={"id":eid,"source":sid,"from":a,"to":b,"relation":rel,"stance":stance,"conditions":conditions,"evidence":refs}
            if e.get("relation_label"):
                record["relation_label"]=e["relation_label"]
            if eid in edges:
                edges[eid]["evidence"].extend(r for r in refs if r not in edges[eid]["evidence"])
            else:
                edges[eid]=record
        except (KeyError,ValueError,TypeError,AttributeError) as exc:
            review.append({"edge":i,"reason":str(exc)})
    for q in draft.get("queries",[]):
        fields=set(q)-{"question","from","to","source","relation","stance","node"}
        if fields or not set(q).intersection({"from","to","source","relation","stance","node"}):
            review.append({"query":q.get("question"),"reason":"missing or unsupported filter"})
            continue
        hits=[]
        for e in edges.values():
            if any(q[k]!=e[k] for k in ("source","relation","stance") if k in q):
                continue
            endpoints={k:canonical(e[k]) for k in ("from","to")}
            requested = {k:by_ref.get(tuple(q[k])) for k in ("from","to") if k in q}
            if any(nid is None or canonical(nid)!=endpoints[k] for k,nid in requested.items()):
                continue
            if "node" in q:
                nid=by_ref.get(tuple(q["node"]))
                if not nid or canonical(nid) not in endpoints.values():
                    continue
            hits.append(e)
        queries.append({"question":q.get("question",""),"filter":q,"status":"found" if hits else "no_supported_match",
                        "edges":[e["id"] for e in hits],"nodes":sorted({e[k] for e in hits for k in ("from","to")}),
                        "evidence":[r for e in hits for r in e["evidence"]]})
    groups=defaultdict(list)
    for e in edges.values():
        groups[(canonical(e["from"]),e["relation"],e.get("relation_label",""),canonical(e["to"]),e["conditions"])].append(e)
    conflicts=[[e["id"] for e in g] for g in groups.values() if {"observed","negated"} <= {e["stance"] for e in g}]
    missing = set(evidence.meta) - {e["source"] for e in edges.values()}
    if missing:
        review.append({"sources_without_supported_edge":sorted(missing),"reason":"inspect each original paper or document a coverage gap"})
    if len(queries)<3:
        review.append({"queries_executed":len(queries),"reason":"the task requires at least three actual queries"})
    return {"sources":evidence.meta,"nodes":list(nodes.values()),"edges":list(edges.values()),"alignments":merges,
            "queries":queries,"possible_conflicts":conflicts,"review":review,"status":"partial" if review or not edges else "validated_evidence"}


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    for field in ("corpus","draft","output"):
        parser.add_argument(field,type=Path)
    args=parser.parse_args()
    save(args.output,run(load(args.corpus),load(args.draft)))

