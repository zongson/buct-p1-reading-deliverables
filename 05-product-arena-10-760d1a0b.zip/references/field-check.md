# 图谱现场核对卡

- **看输入**（虚构） 甲论文 `p7` 写「薄膜 L3 的透射率在 450 nm 为 80%」，乙论文 `p4` 写「薄膜 L3 的透射率在 650 nm 为 80%」。两篇各自定义 L3 为本批样品。
- **查错** 两个 `sample` 或两个 `quantity` 的 `canonical` 相同，就误把同名样品或等值观测当成同一实体。
- **判定与修正** 按 `evidence` 的 `source`、`locator`、`quote` 回查两段及样品定义。Agent 核对编号范围、指标、单位和波长。透射率指标确认同义后可合并。样品和观测分别设 `keep_separate`，保留各自的 `source`、`local` 和源内边，在 `conditions` 写明波长。
- **自动检查** `graph.py` 绑定引文并校验边的两端同源。样品合并要求双方引文都含 `shared_identifier`，同类型 `quantity` 显式合并可通过。`possible_conflicts` 只提示同组同条件下 `observed` 与 `negated` 并存，观测是否可比由 Agent 判定。