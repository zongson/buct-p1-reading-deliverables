---
name: parallel-paper-translation
description: Translate academic papers into paragraph-aligned bilingual text with locked terminology, recoverable source locations, and quantitative and semantic checks.
---

# 证据可回溯的文献翻译

运行时先读 `/input/case.json`、`task.md` 和实际材料，记录 case_id、目标语种/受众、范围、原始 output_contract、要求的文件名与格式。以页面、段落、表图或实际文件路径作为证据坐标。技能安装位置为 `/skills/weekly-skill`；以下脚本均为 Python 3.9+ 标准库。辅助脚本的 JSON 是工作文件，须将实际成果映射到原合同的全部字段。过程文件放 `/app/work`，最终文件和 `result.json` 放 `/app/output`。记录来源、改动、状态及未决项；缺页、无法读取或要求超出材料时，保留可交付部分并准确注明缺口。编辑 Office 文件时同时渲染 PDF/PNG 检查并随成果保留。

## 从原文建立对应关系

1. 按题要求覆盖正文、标题、图表题注和表头、脚注或明确的段落范围。PDF 可用 `pdftotext -layout` 提取，也要比对原页图像的跨栏顺序、脚注和公式。对扫描页仅在确有内容时 OCR。保留印刷页与物理页差异。PDF 软换行可合段，跨页连续句保留两个原始范围；避免把连字符、化学式或同名缩写错误合并。标记无法辨认处并记录页码。
2. 将原文编为唯一 ID。可用 `python scripts/bilingual.py index source.txt manifest.json`；输入以空行分段、换页符分页。此方式给出解码后字符范围；若版面复杂，直接按原版构造 manifest 数组，每行至少含 id、source，并补 locator（图/表/页/段/单元格），可携带其他字段。核对清单覆盖请求范围，再翻译。
3. 从材料自己的定义、符号和首现展开式创建术语表。最终表包含原词、目标译名、首次证据位置、领域含义与允许异形。多义词按语境分条，以原句定夺；辅助脚本接受简化的 source→target 字典或备选译名数组。先统一确定重复术语、专有名词、缩写和图题，保留术语选择依据。
4. 每次处理连续段块，携带已确认术语及前后一段上下文，只输出目标 ID 一次。逐分句比对关系主语、宾语、否定作用域、比较方向、条件和模态强度。保留小数、误差、单位、公式、上下标和交叉引用。证据强度不足时保留限定语言。对歧义给出候选译法及依据，不擅自补原文缺失部分。按要求翻译表头或图注时保留行列对应。
5. 把译文保存成 ID→译文 JSON，用 `python scripts/bilingual.py check manifest.json target.json /app/work/review --glossary terms.json` 生成可编辑双语 Markdown 和审查报告。检查缺项、数量及单位配对、公式、引用、图表编号和术语，同时人工复核否定、数量对应对象以及术语报告的假阳性。比较条件转换或目标语言正常改写时，保留裁定理由，避免用机械替换掩盖缺失。语义标记词表以中英文为主。
6. 交付分段双语稿、证据定位、术语表和未决项，合同指定其他格式时转为相应文件。汇总分母为请求范围内的原文段落/题注数，覆盖数仅计真实译出的段落。记录发现并修复的问题及剩余人工项；平台成绩和正式对照由平台运行。

## 最小调用示例

以下为示例，工作目录准备 `source.txt` 内容 `Figure 2 shows a 5 mg sample.`，`target.json` 内容 `{"p1.1":"图2显示一个5毫克的样品。"}`，`terms.json` 内容 `{"sample":"样品"}`。运行上述 index 和 check 两步。示例产物中 p1.1 会对齐原句和译句，图编号与质量单位相符；若改为 50 毫克，核验报告会列出数量和带单位数值的变化。

## 案例合同复核

运行 `python /skills/weekly-skill/scripts/verify_contract.py /input/case.json /app/output/result.json`。修复 errors，按原题逐条确认 review 和产物路径。此工具检查能明确识别的 JSON 契约与 case_id。

遇到本题的典型边界输入时，可参考 [专项核对卡](references/field-check.md)，按其中的示例区分自动检查与需要回原文判定的部分。
