# 中英逐段对齐现场核对卡

**虚构光学例。** 清单 `p2.1` 的 `source` 为 “The filter did not transmit 510 nm light but transmitted 530 nm light.” 同一 ID 的误译为“滤片透过了 510 纳米的光，却未透过 530 纳米的光。”

**脚本核对。** 用 `python scripts/bilingual.py check manifest.json target.json review`，按 ID 查看 `bilingual.md` 和 `bilingual-audit.json`。脚本逐段按出现次数比较 `quantity` 和 `value_unit`，将“纳米”归一为 `nm`。本例两项均一致；两边都命中否定词，因此 `semantic_review` 不会产生 `polarity` 提示。

**回原文裁定。** 用 `page` 找到第 2 页，用 `start`、`end` 在解码后的源文本中定位原段。Agent 逐分句确认否定修饰哪个动作、数字和单位对应哪束光。原文否定的是透过 510 纳米光，肯定的是透过 530 纳米光。将同一 ID 改为“滤片未透过 510 纳米的光，但透过了 530 纳米的光”，复查两组波长与各自谓语。