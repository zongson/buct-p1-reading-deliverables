"""Build a source manifest, then audit and render agent-authored translations."""
import argparse
from collections import Counter
import json
from pathlib import Path
import re
import unicodedata


def read(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError(f"Duplicate JSON key {key!r}; reconcile conflicting translations first.")
            result[key] = value
        return result
    return json.loads(Path(path).read_text(encoding="utf-8-sig"), object_pairs_hook=unique)


def save(path, obj):
    Path(path).write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def segment(text):
    rows = []
    offset = 0
    for page, page_text in enumerate(text.split("\f"), 1):
        # Coordinates refer to the UTF-8-decoded source, after universal newline handling.
        pattern = r"\S[\s\S]*?(?=\n[ \t]*\n|\Z)"
        for n, m in enumerate(re.finditer(pattern, page_text), 1):
            value = m.group().rstrip()
            rows.append({"id": f"p{page}.{n}", "page": page, "start": offset + m.start(),
                         "end": offset + m.start() + len(value), "source": value})
        offset += len(page_text) + 1
    return rows


FORMULA = re.compile(r"\$\$[\s\S]+?\$\$|(?<!\\)\$(?:\\.|[^$\n])+?\$|\\\([\s\S]+?\\\)|\\\[[\s\S]+?\\\]")
CITE = re.compile(r"\[\s*\d+(?:\s*[,;–—-]\s*\d+)*\s*\]")
NUMBER = re.compile(r"(?<![A-Za-z0-9])(?:[−+-]?\d+(?:,\d{3})*(?:\.\d+)?(?:[eE][+-]?\d+)?|[−+-]?\.\d+)(?:\s*[%‰])?")
NEG = re.compile(r"\b(?:not|no|never|without|neither|failed to)\b|未|无|没有|不能|不", re.I)
HEDGE = re.compile(r"\b(?:may|might|possibly|suggest\w*|potential\w*|could|likely|appears?)\b|可能|提示|推测|或许|有望", re.I)
UNIT_NAMES = {"毫克":"mg", "千克":"kg", "克":"g", "毫秒":"ms", "秒":"s", "分钟":"min",
              "纳米":"nm", "微米":"μm", "毫米":"mm", "厘米":"cm", "毫升":"mL", "摄氏度":"°C",
              "微升":"μL", "°C":"°C", "℃":"°C", "μm":"μm", "µm":"μm", "µL":"μL"}
UNIT_NAMES.update({u:u for u in "mg kg g ms s min nm mm cm mL μL K kPa Pa mmol mol".split()})
UNIT = re.compile(r"([−+-]?\d+(?:\.\d+)?)\s*(" +
                  "|".join(map(re.escape, sorted(UNIT_NAMES, key=len, reverse=True))) + r")(?![A-Za-z])")
XREF = re.compile(r"(Figure|Fig\.?|Table|图|表)\s*(\d+[a-z]?)", re.I)


def protected(text):
    normal = unicodedata.normalize("NFKC", text).replace("−", "-")
    # Keep math verbatim even when the surrounding language changes.
    math = [re.sub(r"\s+", "", m[0]) for m in FORMULA.finditer(normal)]
    refs = [re.sub(r"\s+|[–—]", lambda m: "-" if m[0] in {"–", "—"} else "", val)
            for val in CITE.findall(normal)]
    plain = CITE.sub(" ", FORMULA.sub(" ", normal))
    nums = [v.replace(",", "").replace(" ", "") for v in NUMBER.findall(plain)]
    units = Counter(value + " " + UNIT_NAMES[unit] for value, unit in UNIT.findall(plain))
    xrefs = Counter(("table" if name.lower() in {"table", "表"} else "figure") + idx.lower()
                    for name, idx in XREF.findall(plain))
    return {"math": Counter(math), "citation": Counter(refs), "quantity": Counter(nums),
            "value_unit": units, "cross_reference": xrefs}


def contains(text, term):
    left = r"(?<![A-Za-z0-9])" if re.match("[A-Za-z0-9]", term[:1]) else ""
    right = r"(?![A-Za-z0-9])" if re.match("[A-Za-z0-9]", term[-1:]) else ""
    return re.search(left + re.escape(term) + right, text, re.I) is not None


def audit(rows, translated, glossary):
    if len({r["id"] for r in rows}) != len(rows):
        raise ValueError("Source IDs must be unique.")
    ids = {r["id"] for r in rows}
    errors = [{"kind":"unmatched_id","id":key} for key in translated if key not in ids]
    aligned = []
    reviews = []
    for row in rows:
        key, source = row["id"], row["source"]
        target = translated.get(key, "")
        if not isinstance(target, str):
            raise ValueError(f"{key}: translation must be a string")
        aligned.append({**row, "translation":target})
        if not target.strip():
            errors.append({"id":key,"kind":"missing_translation"})
            continue
        before, after = protected(source), protected(target)
        for group in before:
            if before[group] != after[group]:
                errors.append({"id":key,"kind":group, "missing":list((before[group]-after[group]).elements()),
                               "extra":list((after[group]-before[group]).elements())})
        for src, allowed in glossary.items():
            choices = [allowed] if isinstance(allowed, str) else allowed
            if contains(source, src) and not any(contains(target, term) for term in choices):
                errors.append({"id":key,"kind":"term","source_term":src,"accepted":choices})
        for label, rx in (("polarity", NEG), ("certainty", HEDGE)):
            if bool(rx.search(source)) != bool(rx.search(target)):
                reviews.append({"id":key, "kind":label, "action":"Inspect the actual clause in both languages."})
    return {"rows":aligned, "checks":errors, "semantic_review":reviews}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    sub = ap.add_subparsers(dest="cmd", required=True)
    prep = sub.add_parser("index")
    prep.add_argument("source"); prep.add_argument("manifest")
    check = sub.add_parser("check")
    for name in ("manifest","translations","output"):
        check.add_argument(name)
    check.add_argument("--glossary")
    ns = ap.parse_args()
    if ns.cmd == "index":
        rows = segment(Path(ns.source).read_text(encoding="utf-8-sig"))
        save(ns.manifest, rows)
    else:
        result = audit(read(ns.manifest), read(ns.translations), read(ns.glossary) if ns.glossary else {})
        dest = Path(ns.output)
        dest.mkdir(parents=True, exist_ok=True)
        save(dest/"bilingual-audit.json", result)
        blocks = [f"## {r['id']}\n\n{r['source']}\n\n{r['translation']}" for r in result["rows"]]
        (dest/"bilingual.md").write_text("\n\n".join(blocks)+"\n",encoding="utf-8")
        print(json.dumps({"segments":len(result["rows"]), "checks":len(result["checks"]),
                          "semantic_review":len(result["semantic_review"])}))


if __name__ == "__main__":
    main()
