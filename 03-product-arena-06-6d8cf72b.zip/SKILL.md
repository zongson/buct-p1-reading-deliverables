---
name: build-source-linked-paper-notes
description: Turn scientific papers and supporting material into section-aligned, searchable notes and a paper card with exact source anchors, conditions, and explicit gaps.
---

# 可追溯的论文笔记

先读 /input/case.json、task.md、指定的原始材料和 output_contract。确认这次是要求论文卡片、章节摘要、知识点清单还是多篇对照。登记原始 case_id、目标语言和材料范围。下面的“索引”和“笔记草稿”是中间接口，最终字段依本次 case 原契约。

1. 建证据索引。用 `python /skills/weekly-skill/scripts/evidence.py /app/work/index.json PAPER.pdf SUPPLEMENT.md`。参数顺序决定来源代号。PDF 的 S1.3.2 是第一份材料第 3 个物理页的第 2 个区块；文本材料同位置的中间数字为分段而非页码。来源哈希可检出版本替换。按 sections 或关键词读取必要片段；超长文分节处理。DOCX 按段落提取，包括表格段；需回原文核对表格归属。图、扫描、公式或双栏混排必须从原页渲染核对，用实际页码、图号、表号补充定位。若手工转录了图表，把转录放在带原页、图号和说明的独立来源，保留原文件。允许部分完成。
2. 先抄出论文真实章节目录及子标题，按原顺序排列，附录单列。每节提炼作者要解决的问题、使用的数据/方法、结果或边界，保留有关样本、分母、量纲、比较组、区间和统计条件。区分作者报告与笔记者推论；同名变量跨实验必须带上下文。综述、理论文、负面结果使用符合原文的表述；没有实验时标清适用范围。
3. 将条目写入 /app/work/notebook.json。接口见 examples/notebook.json。title 是真实标题，sections 是原始章节名数组，notes 中的每条含唯一 id、section、field、status、text、evidence（anchor 加原文摘录）、tags，必要时填 conditions。field 的六类是 question/data/method/result/conclusion/limitation；status 为 supported/not_reported/uncertain/conflict。冲突保留两处证据及各自测量条件。缺报写检索过的章节或附件位置到 searched。别名可作为 tags 供检索，勿把简称相同但实体不同的条目归并。
4. 运行 `python /skills/weekly-skill/scripts/notes.py /app/work/index.json /app/work/notebook.json /app/work/notes`。产出可编辑 notes.md、字段和术语反向索引及 audit.json。优先修复错误锚、不一致数字、缺少的字段；数字换算须写清原单位和计算。逐条核对证据能否支持断言（字符串匹配只能证明找到原话）。发现歧义保留 review 并指出人工核对位置。
5. 把真实笔记和证据写进案例指定的结果；输出目录 /app/output。保留原 case_id、output_contract 原字段、真实状态与来源、限制和修改记录。按需另交可编辑 notes.md、notebook.json、可独立回查的索引。检查 result.json 的每个引用可以直接落到原材料；写清哪些字段是未报告、材料缺失或解析失败。相同材料可复用同一份索引，不跨版本复用锚。

有多组数值时可为条目附 measurements 数组，每项写 source_label（原文组名）、value、unit、anchor。一项测量应指向同一短句或表格行。自动校验检查原文同一分句里是否出现组名、数值和单位。一个分句里并排比较两组时，仍需按语义或列头回查绑定关系。

## 最小调用

在技能目录运行 `python scripts/evidence.py index.json examples/sample.md`，再运行 `python scripts/notes.py index.json examples/notebook.json out`。示意输出包括与“Observations”对应的测量条目，内容为人工构造的光学演示。脚本只需 Python 3.9+ 标准库；处理 PDF 另需 Poppler pdftotext 或 PyMuPDF。Markdown 直读，无外部网络、模型密钥或自动 OCR 依赖。实际摘要/字段归类由调用本技能的 Agent 生成，脚本负责来源和结构核验。


## 案例合同复核

运行 `python /skills/weekly-skill/scripts/verify_contract.py /input/case.json /app/output/result.json`。修复 errors，按原题逐条确认 review 和产物路径。此工具检查能明确识别的 JSON 契约与 case_id。

遇到本题的典型边界输入时，可参考 [专项核对卡](references/field-check.md)，按其中的示例区分自动检查与需要回原文判定的部分。
