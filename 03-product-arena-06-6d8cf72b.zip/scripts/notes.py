"""Audit source-backed note records and render an editable, section-aligned paper notebook."""
import argparse
import json
import re
import unicodedata
from collections import defaultdict
from pathlib import Path

from evidence import norm, read_json, save, verify_refs

FIELDS=("question","data","method","result","conclusion","limitation")
STATES=("supported","not_reported","uncertain","conflict")
NUMBER=re.compile(r"(?<![A-Za-z0-9.])[-−+]?\d+(?:[.,]\d+)*(?:[eE][-+]?\d+)?[%‰]?")


def quantities(text):
    text=unicodedata.normalize("NFKC",text).replace("−","-")
    return set(NUMBER.findall(text))


def compile_notes(index, notebook):
    anchors=index["anchors"]
    sections=notebook["sections"]
    errors,warnings=[],list(index.get("issues",[]))
    by_section=defaultdict(list)
    by_field=defaultdict(list)
    by_term=defaultdict(list)
    used=set()
    for item in notebook["notes"]:
        key=item["id"]
        if key in used:
            errors.append(f"duplicate note {key}")
        used.add(key)
        field,state=item["field"],item["status"]
        refs=item.get("evidence",[])
        if item["section"] not in sections or field not in FIELDS or state not in STATES:
            errors.append(f"{key}: unknown section, field or status")
        if not item.get("text","").strip():
            errors.append(f"{key}: empty note")
        if state!="not_reported" or refs:
            errors.extend(f"{key}: {msg}" for msg in verify_refs(refs, anchors))
        if state=="not_reported" and not item.get("searched"):
            errors.append(f"{key}: document inspected and search scope required")
        if state=="conflict" and len({(r["anchor"],r["quote"]) for r in refs})<2:
            errors.append(f"{key}: both conflicting passages required")
        quote=" ".join(r.get("quote","") for r in refs)
        if state=="supported":
            extra=quantities(item["text"])-quantities(quote)
            if extra:
                warnings.append(f"{key}: verify numbers or conversions {sorted(extra)} against {[r['anchor'] for r in refs]}")
            for m in item.get("measurements",[]):
                local=[r["quote"] for r in refs if r["anchor"]==m.get("anchor")]
                # Use a single excerpt and clause for group-value attribution.
                # A reversed translation or implicit reference still needs semantic review.
                clauses=[c for q in local for c in re.split(r"[;；。!?]|\.(?=\s|$)",q)]
                good=any(norm(m.get("source_label","")).casefold() in norm(c).casefold()
                         and quantities(str(m.get("value",""))) & quantities(c)
                         and norm(m.get("unit","")).casefold() in norm(c).casefold() for c in clauses)
                if not good or not m.get("source_label"):
                    warnings.append(f"{key}: verify group/value/unit attribution at {m.get('anchor')}")
        by_section[item["section"]].append(item)
        by_field[field].append(key)
        for term in item.get("tags",[]):
            if norm(term):
                by_term[norm(term).casefold()].append(key)
    if not used or not sections:
        errors.append("no notes or source sections")
    for field in FIELDS:
        if not by_field[field]:
            warnings.append(f"paper card lacks field {field}; check case scope")
    out=[f'# {notebook["title"]}',""]
    for section in sections:
        out.extend([f"## {section}",""])
        if not by_section[section]:
            warnings.append(f"{section}: no recorded observations")
        for n in by_section[section]:
            cites=", ".join(r["anchor"] for r in n.get("evidence",[]))
            out.append(f'- **{n["field"]} · {n["id"]}** [{n["status"]}] {n["text"]} ({cites or n.get("searched","")})')
            if n.get("conditions"):
                out.append(f'  - Scope: {n["conditions"]}')
        out.append("")
    out.extend(["## Evidence",""])
    for n in notebook["notes"]:
        for r in n.get("evidence",[]):
            out.append(f'- {n["id"]} → {r["anchor"]} — {r["quote"]}')
    return "\n".join(out),{"errors":errors,"review":warnings,
                "fields":dict(by_field),"terms":dict(by_term),"note_count":len(used)}


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("index");p.add_argument("notebook");p.add_argument("out",type=Path)
    args=p.parse_args()
    text,report=compile_notes(read_json(args.index),read_json(args.notebook))
    args.out.mkdir(parents=True,exist_ok=True)
    save(report,args.out/"audit.json")
    (args.out/"notes.md").write_text(text+"\n",encoding="utf-8")
    print(json.dumps({"errors":len(report["errors"]),"review":len(report["review"])}))
    raise SystemExit(bool(report["errors"]))

