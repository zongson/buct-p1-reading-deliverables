"""Create stable page/paragraph anchors from supplied sources and verify quoted evidence."""
import argparse
import hashlib
import json
import re
import shutil
import subprocess
import unicodedata
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def save(obj, path):
    path=Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False),encoding="utf-8")


def norm(s):
    return " ".join(unicodedata.normalize("NFC",s).replace("\u00ad","").split())


def source_pages(p):
    if p.suffix.lower()==".pdf":
        if shutil.which("pdftotext"):
            result=subprocess.run(["pdftotext","-layout","-enc","UTF-8",str(p),"-"],
                                  capture_output=True,timeout=90)
            if result.returncode:
                raise ValueError(result.stderr.decode("utf-8","replace")[:240])
            pages=result.stdout.decode("utf-8","replace").split("\f")
            return pages[:-1] if pages[-1]=="" else pages
        try:
            import pymupdf
        except ImportError as exc:
            raise ValueError("PDF needs Poppler pdftotext or PyMuPDF") from exc
        with pymupdf.open(p) as doc:
            return [page.get_text(sort=True) for page in doc]
    if p.suffix.lower()==".docx":
        with zipfile.ZipFile(p) as z:
            root=ET.fromstring(z.read("word/document.xml"))
        paragraphs=["".join(n.text or "" for n in para.findall(".//{*}t"))
                    for para in root.findall(".//{*}p")]
        return ["\n\n".join(paragraphs)]
    if p.suffix.lower() not in (".txt",".md",".csv",".tsv",".json",".jsonl",".tex",".bib"):
        raise ValueError("convert this format to a faithful text transcription with locators first")
    text=p.read_text(encoding="utf-8-sig")
    if p.suffix.lower()==".json":
        text=json.dumps(json.loads(text),indent=2,ensure_ascii=False)
    return text.split("\f")


def index(paths):
    sources,anchors,issues=[],{},[]
    for num, path in enumerate(paths,1):
        p=Path(path)
        key=f"S{num}"
        try:
            pages=source_pages(p)
            digest=hashlib.sha256(p.read_bytes()).hexdigest()
            sources.append({"source_id":key,"file":p.name,"sha256":digest})
        except (OSError,ValueError,subprocess.SubprocessError,zipfile.BadZipFile,ET.ParseError) as exc:
            issues.append(f"{key} {p.name}: {exc}")
            continue
        for n,page in enumerate(pages,1):
            if not page.strip():
                issues.append(f"{key} segment {n}: no extracted text; inspect original scan")
            part=0
            for block in re.split(r"\n\s*\n",page.strip()):
                # Long paragraphs get smaller searchable anchors without truncation.
                lines=block.splitlines()
                for offset in range(0,len(lines),8):
                    s="\n".join(lines[offset:offset+8]).strip()
                    if s:
                        part+=1
                        anchors[f"{key}.{n}.{part}"]={"source_id":key,
                           "page":n if p.suffix.lower()==".pdf" else None,
                           "segment":n,"part":part,"text":s}
    return {"sources":sources,"anchors":anchors,"issues":issues}


def verify_refs(refs, anchors):
    issues=[]
    if not isinstance(refs,list) or not refs:
        return ["missing source evidence"]
    for ref in refs:
        aid,quote=ref.get("anchor",""),norm(ref.get("quote",""))
        if aid not in anchors:
            issues.append(f"unknown anchor {aid}")
        elif not quote or quote not in norm(anchors[aid]["text"]):
            issues.append(f"quote does not match {aid}")
    return issues


if __name__=="__main__":
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("output")
    ap.add_argument("sources",nargs="+",help="ordered list of actual local source files")
    args=ap.parse_args()
    data=index(args.sources)
    save(data,args.output)
    print(f'{len(data["anchors"])} anchors, {len(data["issues"])} source warnings')
    raise SystemExit(int(not data["anchors"]))

