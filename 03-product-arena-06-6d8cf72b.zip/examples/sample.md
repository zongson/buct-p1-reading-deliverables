Purpose

We ask whether a neutral filter changes the recorded signal.

Setup

The mock bench used three blue light pulses and a fixed exposure.

Observations

Under fixed exposure, the median was 12 counts with the filter.

Limits

Only the blue source was tested.
